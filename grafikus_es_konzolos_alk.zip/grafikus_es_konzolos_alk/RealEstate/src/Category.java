public class Category {
    int id;
    String Name;

    public Category(int id, String name) {
        this.id = id;
        Name = name;
    }
}
