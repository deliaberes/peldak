public class Seller {
    int id;
    String Name;
    String Phone;

    public Seller(int id, String name, String phone) {
        this.id = id;
        Name = name;
        Phone = phone;
    }
}
